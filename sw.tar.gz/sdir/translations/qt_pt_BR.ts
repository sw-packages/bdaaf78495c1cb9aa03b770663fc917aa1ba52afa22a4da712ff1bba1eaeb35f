<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<dependencies>
<dependency catalog="qtbase_"/>
<dependency catalog="qtscript_"/>
<dependency catalog="qtmultimedia_"/>
<dependency catalog="qtxmlpatterns_"/>
</dependencies>
</TS>
